package com.reto2.sprinboot.app.productos.models.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.reto2.sprinboot.app.productos.models.dao.ProductoDao;
import com.reto2.sprinboot.app.commons.models.entity.producto;

@Service
public class ProductoServiceImpl implements IProductoService {

	@Autowired
	private ProductoDao productoDao;
	@Override
	@Transactional(readOnly = true)
	public List<producto> findAll() {
		return (List<producto>) productoDao.findAll();

	}

	@Override
	public producto findById(Long id) {

		return productoDao.findById(id).orElse(null);
	}

	@Override
	@Transactional
	public producto save(producto producto) {
		return productoDao.save(producto);
	}

	@Transactional
	@Override
	public void deleteById(Long id) {
		productoDao.deleteById(id);
		
	}

}
