package com.reto2.sprinboot.app.productos.models.services;

import java.util.List;

import com.reto2.sprinboot.app.commons.models.entity.producto;

public interface IProductoService {
	
	public List<producto> findAll();
	public producto findById(Long id);
	
	public producto save(producto producto);
	
	public void deleteById(Long id);

}
