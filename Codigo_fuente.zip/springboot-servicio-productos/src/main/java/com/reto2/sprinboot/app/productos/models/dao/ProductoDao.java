package com.reto2.sprinboot.app.productos.models.dao;

import org.springframework.data.repository.CrudRepository;

import com.reto2.sprinboot.app.commons.models.entity.producto;

public interface ProductoDao extends CrudRepository<producto, Long> {

}
