INSERT INTO productos (nombre, precio, created_at) VALUES ('Emergencias_Medicas', 800000, NOW());
INSERT INTO productos (nombre, precio, created_at) VALUES ('Citas_externas', 750000, NOW());
INSERT INTO productos (nombre, precio, created_at) VALUES ('Tratamientos_faciales', 100000, NOW());
INSERT INTO productos (nombre, precio, created_at) VALUES ('Nuevos_afiliados', 500000, NOW());
INSERT INTO productos (nombre, precio, created_at) VALUES ('Ingresos_IPS', 5000000, NOW());