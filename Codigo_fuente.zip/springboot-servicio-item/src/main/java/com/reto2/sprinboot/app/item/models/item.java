package com.reto2.sprinboot.app.item.models;

import com.reto2.sprinboot.app.commons.models.entity.producto;

public class item {

	private producto producto;
	private Integer cantidad;

	public item() {
	}

	public item(producto producto, Integer cantidad) {

		this.producto = producto;
		this.cantidad = cantidad;
	}

	public producto getProducto() {
		return producto;
	}

	public void setProducto(producto producto) {
		this.producto = producto;
	}

	public Integer getCantidad() {
		return cantidad;
	}

	public void setCantidad(Integer cantidad) {
		this.cantidad = cantidad;
	}
	
	public Double getTotal() {
		return producto.getPrecio() * cantidad.doubleValue();
	}

}
