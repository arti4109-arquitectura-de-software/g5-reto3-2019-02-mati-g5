package com.reto2.sprinboot.app.item.models.service;

import java.util.List;

import com.reto2.sprinboot.app.item.models.item;
import com.reto2.sprinboot.app.commons.models.entity.producto;

public interface ItemService {
	
	public List<item> findAll();
	public item findById(Long id, Integer cantidad);
	
	public producto save(producto producto);
	
	public producto update(producto producto, Long id);
	
	public void delete (Long id);

}
