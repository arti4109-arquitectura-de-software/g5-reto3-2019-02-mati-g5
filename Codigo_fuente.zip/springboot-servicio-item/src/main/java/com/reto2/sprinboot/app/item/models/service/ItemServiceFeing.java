package com.reto2.sprinboot.app.item.models.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.reto2.sprinboot.app.item.clientes.ProductoClienteRest;
import com.reto2.sprinboot.app.item.models.item;
import com.reto2.sprinboot.app.commons.models.entity.producto;

@Service("serviceFeing")
public class ItemServiceFeing implements ItemService {
	
	@Autowired
	private ProductoClienteRest clienteFeing;

	@Override
	public List<item> findAll() {
		return clienteFeing.listar().stream().map(p -> new item(p, 1)).collect(Collectors.toList());
	}

	@Override
	public item findById(Long id, Integer cantidad) {
		return new item(clienteFeing.detalle(id), cantidad);
	}

	@Override
	public producto save(producto producto) {
		return clienteFeing.crear(producto);
	}

	@Override
	public producto update(producto producto, Long id) {
		return clienteFeing.update(producto, id);
	}

	@Override
	public void delete(Long id) {
		clienteFeing.eliminar(id);
	}

}
