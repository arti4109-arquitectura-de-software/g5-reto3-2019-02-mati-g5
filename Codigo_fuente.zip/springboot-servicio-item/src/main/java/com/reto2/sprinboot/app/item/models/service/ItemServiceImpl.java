package com.reto2.sprinboot.app.item.models.service;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.reto2.sprinboot.app.item.models.item;
import com.reto2.sprinboot.app.commons.models.entity.producto;

@Service("serviceRestTemplate")

public class ItemServiceImpl implements ItemService {

	@Autowired
	private RestTemplate clienteRest;
	@Override
	public List<item> findAll() {
		List<producto> productos = Arrays.asList(clienteRest.getForObject("http://servicio-productos/listar", producto[].class));
		
		return productos.stream().map(p -> new item(p, 1)).collect(Collectors.toList());
	}

	@Override
	public item findById(Long id, Integer cantidad) {
		Map<String, String> pathVariables = new HashMap<String, String>();
		pathVariables.put("id", id.toString());
		producto producto = clienteRest.getForObject("http://servicio-productos/ver/{id}", producto.class, pathVariables);
		return new item(producto, cantidad);
	}

	@Override
	public producto save(producto producto) {
		HttpEntity<producto> body = new HttpEntity<producto>(producto);
		ResponseEntity<producto> response = clienteRest.exchange("http://servicio-productos/crear", HttpMethod.POST, body, producto.class);
		producto productoResponse = response.getBody();
		return productoResponse;
	}

	@Override
	public producto update(producto producto, Long id) {
		HttpEntity<producto> body = new HttpEntity<producto>(producto);
		Map<String, String> pathVariables = new HashMap<String, String>();
		pathVariables.put("id", id.toString());
		ResponseEntity<producto> response = clienteRest.exchange("http://servicio-productos/editar/{id}", 
				HttpMethod.PUT, body, producto.class, pathVariables);
 		return response.getBody();
	}

	@Override
	public void delete(Long id) {
		Map<String, String> pathVariables = new HashMap<String, String>();
		pathVariables.put("id", id.toString());
		clienteRest.delete("http://servicio-productos/eliminar/{id}", pathVariables);
	}

}
